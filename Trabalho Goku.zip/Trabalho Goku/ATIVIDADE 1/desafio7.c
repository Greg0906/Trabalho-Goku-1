#include <stdio.h>
#include <string.h>

typedef struct {
    char titulo[30];
    char autor[15];
    int ano;
} Livro;

int main() {
    Livro livros[5];
    
    for (int i = 0; i < 5; i++) {
        printf("Digite o título, autor e ano do livro %d:\n", i + 1);
        scanf("%s %s %d", livros[i].titulo, livros[i].autor, &livros[i].ano);
    }
    
    char tituloBusca[30];
    printf("Digite o título do livro que deseja buscar: ");
    scanf("%s", tituloBusca);

    int encontrado = 0;
    for (int i = 0; i < 5; i++) {
        if (strcmp(livros[i].titulo, tituloBusca) == 0) {
            printf("Livro encontrado: Título: %s, Autor: %s, Ano: %d\n", livros[i].titulo, livros[i].autor, livros[i].ano);
            encontrado = 1;
        }
    }
    
    if (!encontrado) {
        printf("Livro não encontrado.\n");
    }

    return 0;
}
