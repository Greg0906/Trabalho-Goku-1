#include <stdio.h>

int main() {
    float vetor[3];
    float matriz[3][3];

    printf("Digite 3 elementos do vetor:\n");
    for(int i = 0; i < 3; i++) {
        scanf("%f", &vetor[i]);
    }

    printf("Digite os elementos da matriz 3x3:\n");
    for(int i = 0; i < 3; i++)
        for(int j = 0; j < 3; j++)
            scanf("%f", &matriz[i][j]);

    printf("Resultado da multiplicação:\n");
    for (int i = 0; i < 3; i++) {
        float resultado = 0;
        for (int j = 0; j < 3; j++) {
            resultado += vetor[j] * matriz[j][i];
        }
        printf("%f ", resultado);
    }
    printf("\n");
    return 0;
}
