#include <stdio.h>

int main() {
    int vetor[5];

    for(int i = 0; i < 5; i++) {
        printf("Digite um número: ");
        scanf("%d", &vetor[i]);
    }

    printf("Vetor na ordem inversa: ");
    for(int i = 4; i >= 0; i--) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
    return 0;
}
