#include <stdio.h>
#include <stdlib.h>

typedef struct Documento {
    int id;
    int numPaginas;
    int prioridade;
    struct Documento* next;
} Documento;

typedef struct Fila {
    Documento* front;
    Documento* rear;
} Fila;

Fila* createFila() {
    Fila* fila = (Fila*)malloc(sizeof(Fila));
    fila->front = NULL;
    fila->rear = NULL;
    return fila;
}

Documento* createDocumento(int id, int numPaginas, int prioridade) {
    Documento* doc = (Documento*)malloc(sizeof(Documento));
    doc->id = id;
    doc->numPaginas = numPaginas;
    doc->prioridade = prioridade;
    doc->next = NULL;
    return doc;
}

void enqueue(Fila* fila, int id, int numPaginas, int prioridade) {
    Documento* doc = createDocumento(id, numPaginas, prioridade);
    
    if (fila->front == NULL) {
        fila->front = doc;
        fila->rear = doc;
    } else {
        Documento* current = fila->front;
        Documento* previous = NULL;
        
        while (current != NULL && current->prioridade <= doc->prioridade) {
            previous = current;
            current = current->next;
        }
        
        if (previous == NULL) {
            doc->next = fila->front;
            fila->front = doc;
        } else {
            previous->next = doc;
            doc->next = current;
            if (current == NULL) {
                fila->rear = doc;
            }
        }
    }
}

Documento* dequeue(Fila* fila) {
    if (fila->front == NULL) {
        return NULL;
    }
    Documento* doc = fila->front;
    fila->front = fila->front->next;
    if (fila->front == NULL) {
        fila->rear = NULL;
    }
    return doc;
}

void simularImpressao(Fila* fila) {
    Documento* doc;

    while ((doc = dequeue(fila)) != NULL) {
        printf("Imprimindo documento ID: %d, Páginas: %d, Prioridade: %d\n", doc->id, doc->numPaginas, doc->prioridade);
        free(doc);
    }
}

int main() {
    Fila* fila = createFila();
    int n;

    printf("Digite o número de documentos: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        int numPaginas, prioridade;
        printf("Digite o número de páginas e prioridade do documento %d: ", i + 1);
        scanf("%d %d", &numPaginas, &prioridade);
        enqueue(fila, i + 1, numPaginas, prioridade);
    }

    simularImpressao(fila);
    free(fila);
    return 0;
}