#include <stdio.h>
#include <stdlib.h>

typedef struct Cliente {
    int id;
    int tempoAtendimento;
    struct Cliente* next;
} Cliente;

typedef struct Fila {
    Cliente* front;
    Cliente* rear;
} Fila;

Fila* createFila() {
    Fila* fila = (Fila*)malloc(sizeof(Fila));
    fila->front = NULL;
    fila->rear = NULL;
    return fila;
}

Cliente* createCliente(int id, int tempoAtendimento) {
    Cliente* cliente = (Cliente*)malloc(sizeof(Cliente));
    cliente->id = id;
    cliente->tempoAtendimento = tempoAtendimento;
    cliente->next = NULL;
    return cliente;
}

void enqueue(Fila* fila, int id, int tempoAtendimento) {
    Cliente* cliente = createCliente(id, tempoAtendimento);
    if (fila->rear == NULL) {
        fila->front = cliente;
        fila->rear = cliente;
    } else {
        fila->rear->next = cliente;
        fila->rear = cliente;
    }
}

Cliente* dequeue(Fila* fila) {
    if (fila->front == NULL) {
        return NULL;
    }
    Cliente* cliente = fila->front;
    fila->front = fila->front->next;
    if (fila->front == NULL) {
        fila->rear = NULL;
    }
    return cliente;
}

void simularAtendimento(Fila* fila) {
    int tempoEspera = 0;
    Cliente* cliente;

    while ((cliente = dequeue(fila)) != NULL) {
        printf("Atendendo cliente ID: %d\n", cliente->id);
        printf("Tempo de espera: %d minutos\n", tempoEspera);
        tempoEspera += cliente->tempoAtendimento;
        free(cliente);
    }
}

int main() {
    Fila* fila = createFila();
    int n;

    printf("Digite o número de clientes: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        int tempoAtendimento;
        printf("Digite o tempo de atendimento do cliente %d: ", i + 1);
        scanf("%d", &tempoAtendimento);
        enqueue(fila, i + 1, tempoAtendimento);
    }

    simularAtendimento(fila);
    free(fila);
    return 0;
}