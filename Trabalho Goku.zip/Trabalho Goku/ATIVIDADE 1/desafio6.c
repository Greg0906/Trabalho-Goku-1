#include <stdio.h>
#include <string.h>

typedef struct {
    char nome[50];
    int matricula;
    float mediaFinal;
} Aluno;

int main() {
    Aluno alunos[10], aprovados[10], reprovados[10];
    int countA = 0, countR = 0;

    for (int i = 0; i < 10; i++) {
        printf("Digite o nome, matricula e media final do aluno %d:\n", i + 1);
        scanf("%s %d %f", alunos[i].nome, &alunos[i].matricula, &alunos[i].mediaFinal);
        if (alunos[i].mediaFinal >= 5.0) {
            aprovados[countA++] = alunos[i];
        } else {
            reprovados[countR++] = alunos[i];
        }
    }

    printf("\nAlunos Aprovados:\n");
    for (int i = 0; i < countA; i++) {
        printf("Nome: %s, Matrícula: %d, Média: %.2f\n", aprovados[i].nome, aprovados[i].matricula, aprovados[i].mediaFinal);
    }

    printf("\nAlunos Reprovados:\n");
    for (int i = 0; i < countR; i++) {
        printf("Nome: %s, Matrícula: %d, Média: %.2f\n", reprovados[i].nome, reprovados[i].matricula, reprovados[i].mediaFinal);
    }
    return 0;
}
