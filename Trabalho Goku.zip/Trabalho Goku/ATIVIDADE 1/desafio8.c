#include <stdio.h>

int main() {
    int array[5];
    int *ptr = array;

    for (int i = 0; i < 5; i++) {
        printf("Digite um valor: ");
        scanf("%d", ptr + i);
    }

    printf("Dobro dos valores lidos:\n");
    for (int i = 0; i < 5; i++) {
        printf("%d ", *(ptr + i) * 2);
    }
    printf("\n");
    return 0;
}
