#include <stdio.h>

void ordenar(int *a, int *b, int *c) {
    int temp;
    if (*a > *b) { temp = *a; *a = *b; *b = temp; }
    if (*a > *c) { temp = *a; *a = *c; *c = temp; }
    if (*b > *c) { temp = *b; *b = *c; *c = temp; }
}

int main() {
    int x, y, z;

    printf("Digite três valores inteiros:\n");
    scanf("%d %d %d", &x, &y, &z);
    
    if (x == y && y == z) {
        printf("Todos os valores são iguais.\n");
    } else {
        ordenar(&x, &y, &z);
        printf("Valores ordenados: %d %d %d\n", x, y, z);
    }
    return 0;
}
