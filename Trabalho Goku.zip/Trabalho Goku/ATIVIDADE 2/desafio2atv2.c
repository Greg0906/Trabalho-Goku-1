#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    char data;
    struct Node* next;
} Node;

typedef struct Stack {
    Node* top;
} Stack;

// Função para inicializar a pilha
Stack* createStack() {
    Stack* stack = (Stack*)malloc(sizeof(Stack));
    stack->top = NULL;
    return stack;
}

// Função para verificar se a pilha está vazia
int isEmpty(Stack* stack) {
    return stack->top == NULL;
}

// Função para adicionar um elemento à pilha (push)
void push(Stack* stack, char data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = stack->top;
    stack->top = newNode;
}

// Função para remover um elemento da pilha (pop)
char pop(Stack* stack) {
    if (isEmpty(stack)) {
        return '\0'; // Retorna um caractere nulo se a pilha estiver vazia
    }
    Node* temp = stack->top;
    char popped = temp->data;
    stack->top = stack->top->next;
    free(temp);
    return popped;
}

// Função para verificar se a expressão está balanceada
int isBalanced(const char* expr) {
    Stack* stack = createStack();
    for (int i = 0; expr[i] != '\0'; i++) {
        char current = expr[i];
        if (current == '(' || current == '{' || current == '[') {
            push(stack, current);
        } else if (current == ')' || current == '}' || current == ']') {
            if (isEmpty(stack)) {
                return 0; // Encontrou um símbolo de fechamento sem correspondente
            }
            char top = pop(stack);
            if ((current == ')' && top != '(') ||
                (current == '}' && top != '{') ||
                (current == ']' && top != '[')) {
                return 0; // Ordem não respeitada
            }
        }
    }
    int balanced = isEmpty(stack); // Se a pilha estiver vazia, a expressão está balanceada
    free(stack); // Libera a memória da pilha
    return balanced;
}

int main() {
    char expr[100];
    printf("Digite uma expressão: ");
    scanf("%s", expr);

    if (isBalanced(expr)) {
        printf("A expressão está balanceada.\n");
    } else {
        printf("A expressão não está balanceada.\n");
    }

    return 0;
}
