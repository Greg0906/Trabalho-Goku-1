#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    char data;
    struct Node* next;
} Node;

typedef struct {
    Node* top;
} Stack;

Stack* createStack() {
    Stack* s = (Stack*) malloc(sizeof(Stack));
    s->top = NULL;
    return s;
}

int isEmpty(Stack* s) {
    return s->top == NULL;
}

void push(Stack* s, char c) {
    Node* novo = (Node*) malloc(sizeof(Node));
    novo->data = c;
    novo->next = s->top;
    s->top = novo;
}

char pop(Stack* s) {
    if (isEmpty(s)) return '\0';

    Node* temp = s->top;
    char valor = temp->data;

    s->top = temp->next;
    free(temp);

    return valor;
}

int combina(char abertura, char fechamento) {
    if (abertura == '(' && fechamento == ')') return 1;
    if (abertura == '{' && fechamento == '}') return 1;
    if (abertura == '[' && fechamento == ']') return 1;
    return 0;
}

int main() {
    char str[100];
    printf("Digite a expressão: ");
    scanf("%s", str);

    Stack* pilha = createStack();
    int valido = 1;

    for (int i = 0; str[i] != '\0'; i++) {

        char c = str[i];

        if (c == '(' || c == '{' || c == '[') {
            push(pilha, c);
        }

        else if (c == ')' || c == '}' || c == ']') {

            if (isEmpty(pilha)) {
                valido = 0;
                break;
            }

            char topo = pop(pilha);

            if (!combina(topo, c)) {
                valido = 0;
                break;
            }
        }
    }

    if (!isEmpty(pilha)) {
        valido = 0;
    }

    if (valido)
        printf("Expressão válida\n");
    else
        printf("Expressão inválida\n");

    return 0;
}