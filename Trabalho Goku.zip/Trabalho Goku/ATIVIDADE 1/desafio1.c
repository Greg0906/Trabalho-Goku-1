#include <stdio.h>

int main() {
    char palavra1[50], palavra2[50], palavra3[50];

    printf("Digite a primeira palavra: ");
    scanf("%s", palavra1);
    printf("Digite a segunda palavra: ");
    scanf("%s", palavra2);
    printf("Digite a terceira palavra: ");
    scanf("%s", palavra3);

    printf("Palavras na ordem inversa: %s %s %s\n", palavra3, palavra2, palavra1);
    return 0;
}
