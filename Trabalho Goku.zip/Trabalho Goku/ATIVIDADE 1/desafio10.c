#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char nome[50];
    float nota;
} Aluno;

Aluno* maiorNota(Aluno* alunos, int n) {
    Aluno* maior = &alunos[0];

    for(int i = 1; i < n; i++) {
        if(alunos[i].nota > maior->nota) {
            maior = &alunos[i];
        }
    }
    return maior;
}

int main() {
    int n;
    printf("Digite o número de alunos: ");
    scanf("%d", &n);

    Aluno* alunos = (Aluno*) malloc(n * sizeof(Aluno));
    
    for(int i = 0; i < n; i++) {
        printf("Digite o nome e a nota do aluno %d:\n", i + 1);
        scanf("%s %f", alunos[i].nome, &alunos[i].nota);
    }

    Aluno* melhorAluno = maiorNota(alunos, n);
    printf("Aluno com maior nota: %s com nota %.2f\n", melhorAluno->nome, melhorAluno->nota);

    free(alunos);
    return 0;
}
